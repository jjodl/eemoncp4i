cd AsyncApi_Consume_Flight_Landing_Events_Java_Project_EEM
java -cp :jars/jackson-annotations-2.10.5.jar:jars/jackson-databind-2.10.5.1.jar:jars/slf4j-api-1.7.30.jar:jars/jackson-core-2.11.4.jar:jars/kafka-clients-2.8.0.jar: AsyncApi_Consume_Flight_Landing_Events_EEM
